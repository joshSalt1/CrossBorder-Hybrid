# Corridor Kit – Hybrid, Compliance‑Anchored Cross‑Border Payments

This repository contains the public artifacts for Joshua Salter’s capstone: a **hybrid blockchain** approach that anchors **tamper‑evident receipts** while keeping KYC/AML, liquidity, and payouts on mature banking rails.

## Contents

- `figures/` – benchmark histograms and the Analytics + ERR flow diagram
- `data/` – KPI summary, sensitivity grid, assumptions file, and sample transactions
- `receipts/` – sample compliance receipt(s) for verification
- `scripts/` – utilities (e.g., `verify_receipt.py`)
- `docs/` – Notion‑ready page content and notes

## Quickstart

### 1) Install
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Verify a receipt hash
```bash
python scripts/verify_receipt.py receipts/receipt_*.json --evidence data/kpi_summary.json
```
- Pass `--evidence` to point at the JSON that was hashed. The script recomputes **SHA‑256** of the evidence and compares it to the hex hash stored in the receipt (field: `hash`).

### 3) Explore figures and data
Open files in `figures/` and `data/`. The histograms show cost/time distributions for incumbent vs. blockchain‑assist lanes.

## Notes

- Evidence stays **off‑chain**; only the hex hash is anchored to a low‑energy chain to make tampering **detectable**.
- Keep secrets and real PII **out** of the repo. Use environment variables for API keys.
- The included data are illustrative; replace with corridor‑specific partner quotes/telemetry when available.
