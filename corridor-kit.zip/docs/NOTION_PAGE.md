# Cross-Border Payments, Done Right
**Compliance-anchored hybrid blockchain for the U.S. → Mexico corridor**

**Owner:** Joshua Salter

## TL;DR
- Make payments cheaper, faster, and more transparent **without** weakening regulatory assurance.
- Selectively anchor **SHA-256** hashes of receipts on-chain; keep full evidence **off-chain**.
- APIs: **Quote → Decide → Execute → Receipt**, with ERR governance and KRIs.

## Key Assets
- Figures: see `figures/`
- Data: see `data/`
- Receipts: see `receipts/`
- Diagram: `figures/analytics_err_flow.png`
