#!/usr/bin/env python3
import argparse, json, hashlib, sys, os

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(description='Verify receipt hash against evidence JSON.')
    p.add_argument('receipt', help='Path to receipt JSON containing a hex field "hash"')
    p.add_argument('--evidence', required=True, help='Path to evidence JSON that was hashed')
    args = p.parse_args()

    if not os.path.exists(args.receipt):
        print(f'Receipt not found: {args.receipt}', file=sys.stderr); sys.exit(2)
    if not os.path.exists(args.evidence):
        print(f'Evidence not found: {args.evidence}', file=sys.stderr); sys.exit(2)

    with open(args.receipt) as f:
        rj = json.load(f)
    rec_hash = rj.get('hash') or rj.get('receipt_hash') or rj.get('evidence_hash')
    if not rec_hash:
        print('No "hash" field found in receipt JSON.', file=sys.stderr); sys.exit(3)

    ev_hash = sha256_file(args.evidence)
    ok = (rec_hash.lower() == ev_hash.lower())

    print('Receipt hash:', rec_hash)
    print('Evidence  hash:', ev_hash)
    print('RESULT:', 'MATCH' if ok else 'MISMATCH')
    sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
